module F = Format

(* practice & homework *)
let rec interp_e (e : Ast.expr) (s : Store.t) : Store.value = 
  match e with
  | Num i -> Store.NumV i
  | Var e -> Store.find e s
  | Bool b -> Store.BoolV b
  | Add (e1,e2) -> begin
                    match ((interp_e e1 s), (interp_e e2 s)) with
                    | (Store.NumV nv1, Store.NumV nv2) -> Store.NumV (nv1 + nv2)
                    | (_, _) -> failwith (F.asprintf "Invalid addtion: %a + %a" Ast.pp_e e1 Ast.pp_e e2)
                   end
  | Sub (e1,e2) -> begin
                    match ((interp_e e1 s), (interp_e e2 s)) with
                    | (Store.NumV nv1, Store.NumV nv2) -> Store.NumV (nv1 - nv2)
                    | (_, _) -> failwith (F.asprintf "Invalid subtraction: %a - %a" Ast.pp_e e1 Ast.pp_e e2)
                   end
  | Lt (e1,e2) -> begin
                    match ((interp_e e1 s), (interp_e e2 s)) with
                    | (Store.NumV nv1, Store.NumV nv2) -> Store.BoolV(nv1 < nv2)
                    | (_, _) -> failwith (Format.asprintf "Invalid less-than: %a < %a" Ast.pp_e e1 Ast.pp_e e2)
                   end
  | Gt (e1, e2) -> begin
                    match ((interp_e e1 s), (interp_e e2 s)) with
                    | (Store.NumV nv1, Store.NumV nv2) -> Store.BoolV(nv1 > nv2)
                    | (_, _) -> failwith (Format.asprintf "Invalid greater-than: %a > %a" Ast.pp_e e1 Ast.pp_e e2)
                   end
  | Eq (e1, e2) -> begin
                    match ((interp_e e1 s), (interp_e e2 s)) with
                    | (Store.NumV nv1, Store.NumV nv2) -> Store.BoolV (nv1 = nv2)
                    | (Store.BoolV b1, Store.BoolV b2) -> Store.BoolV (b1 = b2)
                    | (_, _) -> failwith (Format.asprintf "Invalid equal-to: %a = %a" Ast.pp_e e1 Ast.pp_e e2)
                   end
  | And (e1, e2) -> begin
                     match ((interp_e e1 s), (interp_e e2 s)) with
                     | (Store.BoolV b1, Store.BoolV b2) -> Store.BoolV (b1 && b2)
                     | (_, _) -> failwith (Format.asprintf "Invalid logical-and: %a && %a" Ast.pp_e e1 Ast.pp_e e2)
                    end
  | Or (e1, e2) -> begin
                    match ((interp_e e1 s), (interp_e e2 s)) with
                    | (Store.BoolV b1, Store.BoolV b2) -> Store.BoolV (b1 || b2)
                    | (_, _) -> failwith (Format.asprintf "Invalid logical-or: %a || %a" Ast.pp_e e1 Ast.pp_e e2)
                   end
(* practice & homework *)
let rec interp_s (stmt : Ast.stmt) (s : Store.t) : Store.t =
    match stmt with
    | AssignStmt (x, e) -> Store.insert x (interp_e e s) s
    | IfStmt (e, stmtList, optionStmtList) -> begin
                                                match (interp_e e s) with
                                                | Store.BoolV true -> begin
                                                                        match stmtList with
                                                                        | [] -> s
                                                                        | aStmtList -> let rec stmtListrec slist s' =
                                                                                                    match slist with
                                                                                                    | [] -> s'
                                                                                                    | h::t -> stmtListrec t (interp_s h s')
                                                                                       in
                                                                                       stmtListrec aStmtList []
                                                                      end
                                                | Store.BoolV false -> begin
                                                                         match optionStmtList with
                                                                         | None -> s
                                                                         | Some stmtList -> let rec stmtListrec slist s' =
                                                                                                        match slist with
                                                                                                        | [] -> s'
                                                                                                        | h::t -> stmtListrec t (interp_s h s')
                                                                                            in
                                                                                            stmtListrec stmtList s
                                                                       end
                                                | (_) -> failwith (Format.asprintf "Not a boolean: %a" Ast.pp_e e)
                                              end
(* practice & homework *)
let interp (p : Ast.program) : Store.t = 
  match p with
  | Ast.Program stmtList ->  let rec stmtListrec slist s' =
                                                        match slist with
                                                        | [] -> s'
                                                        | h::t -> stmtListrec t (interp_s h s')
                             in
                             stmtListrec stmtList []
