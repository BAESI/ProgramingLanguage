module F = Format

type t = (string * string) list

let empty = []

let add key value map = 
        (key, value)::map 

let rec find key map =
        match map with
        | [] -> failwith "No such key exists"
        | (l , r)::t -> if l = key then r
                        else find key t
              
let rec erase key map = 
        match map with
        | [] -> failwith "No such key exists"
        |(l , r)::t -> if l = key then t
                        else (l ,r ):: (erase key t)                                

let print_map fmt map =
    let rec print_map_impl map = 
      match map with
      | [] -> ()
      | (k, v):: t -> 
            let () = F.fprintf fmt " (%s, %s) " k v in
            print_map_impl t
    in
    let () = F.fprintf fmt "[ " in
    let () = print_map_impl map in
    F.fprintf fmt " ]"
