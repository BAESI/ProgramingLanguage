let split lst =
        let rec split_tail lst acc1 acc2 =
                match lst with
                | h::t -> (match h with
                           |(l,r) -> split_tail t (l::acc1) (r::acc2))
                | [] -> (List.rev acc1,List.rev acc2)
        in
        split_tail lst [] []
   
let combine lst1 lst2 =
        let rec combine_tail lst1 lst2 acc =
                match lst1 with
                |h1::t1 -> (match lst2 with
                           |[] -> acc
                           |h2::t2 -> combine_tail t1 t2 ((h1,h2)::acc))
                |[] -> List.rev acc
        in
        combine_tail lst1 lst2 [] 

