module F = Format

let rec interp_e (fenv : FEnv.t) (s : Store.t) (e : Ast.expr) : int =
  match e with
  | Num e1 -> e1
  | Add (e1,e2) -> interp_e fenv s e1 + interp_e fenv s e2
  | Sub (e1,e2) -> interp_e fenv s e1 - interp_e fenv s e2
  | Id k1 -> Store.find k1 s
  | LetIn (x,k1,k2) -> interp_e fenv (Store.insert x (interp_e fenv s k1) s) k2
  | FCall (x,el) -> match (FEnv.find x fenv) with
                    |(p,b) -> let rec insert_param_elem p el s =
                                match p, el with
                                | h1::t1, h2::t2 -> insert_param_elem t1 t2 (Store.insert h1 (interp_e fenv s h2) s)
                                | _,_-> s
                              in
                              interp_e fenv (insert_param_elem p el s) b

let interp_d (fenv : FEnv.t) (fd : Ast.fundef) : FEnv.t =
  match fd with 
  | FDef (x, p, e) -> FEnv.insert x p e fenv

(* practice *)
let interp (p : Ast.f1vae) : int =
  match p with
  | Prog (d , e) ->
            let rec interp_d_impl d fenv =
               match d with
               | [] -> fenv
               | h::t -> interp_d_impl t (interp_d fenv h)
            in
            interp_e (interp_d_impl d []) [] e
