module F = Format 

module Interp = struct 
type unop = Neg
type binop = Add|Sub|Mul|Div
type exp = Constant of int 
        |Unary of unop*exp
        |Binary of exp*binop*exp

let rec eval exp =
        match exp with
        |Constant exp -> exp 
        |Binary (exp1, binop, exp2)-> ( match binop with 
                                        |Add -> eval exp1 +eval exp2
                                        |Sub -> eval exp1 -eval exp2 
                                        |Mul -> eval exp1 *eval  exp2
                                        |Div -> eval exp1 /eval  exp2
        ) 
        |Unary (unop,exp) -> ( match unop with
                               |Neg -> (eval exp) * -1
        )
end  





