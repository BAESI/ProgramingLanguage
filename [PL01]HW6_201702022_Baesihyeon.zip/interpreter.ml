module F = Format

let rec interp (e: Ast.ae) : int =
        match e with 
        | Add (e1, e2) -> interp e1 + interp e2
        | Sub (e1, e2) -> interp e1 - interp e2
        | Neg e1 -> -interp e1
        | Num e1 -> e1 
