let f x = 2 * x in
let rec sum n m f =
             if m = n  then f(n)
             else f(m) + (sum n (m-1) f)
in
Format.printf "result: %d\n" (sum 1 5 f)
