module F = Format

(* practice & homework *)
let rec interp_e (s : Store.t) (e : Ast.expr) : Store.value = 
   match e with
   | Num i -> Store.NumV i
   | Add (e1,e2) -> begin
                     match ((interp_e s e1), (interp_e s e2)) with
                     | (Store.NumV nv1, Store.NumV nv2) -> Store.NumV(nv1 + nv2)
                     | (_,_) -> failwith (F.asprintf "Invalid addtion: %a + %a" Ast.pp_e e1 Ast.pp_e e2)
                    end
   | Sub (e1,e2) -> begin
                     match ((interp_e s e1), (interp_e s e2)) with
                     | (Store.NumV nv1, Store.NumV nv2) -> Store.NumV (nv1 - nv2)
                     | (_ , _) -> failwith (F.asprintf "Invalid subtraction: %a - %a" Ast.pp_e e1 Ast.pp_e e2)
                     end
   | Id x -> begin
               match (Store.find x s) with
               | Store.FreezedV(e, t) -> interp_e t e
               | t -> t
             end
   | LetIn (x,e1,e2) -> interp_e (Store.insert x (interp_e s e1) s) e2
   | RLetIn(x,e1,e2) -> begin
                           match interp_e s e1 with
                           | Store.ClosureV (v,e,s') ->
                               let rec s'' = (x,(Store.ClosureV (v,e,s''))) :: s' in
                               interp_e s'' e2
                           | _ -> failwith (F.asprintf "Not a function %a" Ast.pp_e e1)
                        end
   | App (e1,e2) -> begin
                     match (interp_e s e1) with
                     | Store.ClosureV (x, e3, t) -> (interp_e (Store.insert x (Store.FreezedV (e2,s)) t) e3)
                     | _ -> failwith (F.asprintf "Not a function %a" Ast.pp_e e1)
                    end
   | Fun (x,e1) -> Store.ClosureV (x,e1,s)
   | Lt(e1, e2) -> begin
                    match (interp_e s e1, interp_e s e2) with
                    | NumV n1,NumV n2 -> if n1 < n2 then ClosureV("x",Fun("Y",(Id "x")),[])
                                                else ClosureV("x",Fun("y",(Id "y")),[])
                    | _,_ -> failwith (F.asprintf "Invalid less-than: %a < %a" Ast.pp_e e1 Ast.pp_e e2)
                   end


(* practice & homework *)
let interp (p : Ast.fvae) : Store.value =
  match p with
       | Prog a -> interp_e [] a
  