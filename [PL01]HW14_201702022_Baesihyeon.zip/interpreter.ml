module F = Format

(* practice & homework *)
let rec interp_e (e : Ast.expr) ((env, mem) : Env.t * Mem.t) : Mem.value = 
    match e with
    | Num n -> Mem.NumV n
    | Var x -> Mem.find (Env.find x env) mem
    | Ref x -> Mem.AddressV (Env.find x env)
    | Deref e1 -> begin
                    match Mem.find (Env.find e1 env) mem with
                    | AddressV a -> Mem.find a mem
                    | _ -> failwith(F.asprintf "Noet a memory address: %a" Ast.pp_e (Var e1))
                 end
    | Bool b -> Mem.BoolV b
    | Add (e1, e2) -> begin
                        match ((interp_e e1 (env, mem)), (interp_e e2 (env, mem))) with
                        | (Mem.NumV nv1, Mem.NumV nv2) -> Mem.NumV (nv1 + nv2)
                        | (_, _) -> failwith (F.asprintf "Invalid addtion: %a + %a" Ast.pp_e e1 Ast.pp_e e2)
                      end
    | Sub (e1, e2) -> begin
                        match ((interp_e e1 (env, mem)), (interp_e e2 (env, mem))) with
                        | (Mem.NumV nv1, Mem.NumV nv2) -> Mem.NumV (nv1 - nv2)
                        | (_, _) -> failwith (F.asprintf "Invalid subtraction: %a + %a" Ast.pp_e e1 Ast.pp_e e2)
                      end
    | Lt (e1, e2) -> begin
                        match ((interp_e e1 (env, mem)), (interp_e e2 (env, mem))) with
                        | (Mem.NumV nv1, Mem.NumV nv2) -> Mem.BoolV(nv1 < nv2)
                        | (_, _) -> failwith (F.asprintf "Invalid less-than: %a < %a" Ast.pp_e e1 Ast.pp_e e2)
                     end
    | Gt (e1, e2) -> begin
                        match ((interp_e e1 (env, mem)), (interp_e e2 (env, mem))) with
                        | (Mem.NumV nv1, Mem.NumV nv2) -> Mem.BoolV(nv1 > nv2)
                        | (_, _) -> failwith (F.asprintf "Invalid greater-than: %a > %a" Ast.pp_e e1 Ast.pp_e e2)
                     end
    | Eq (e1, e2) -> begin
                        match ((interp_e e1 (env, mem)), (interp_e e2 (env, mem))) with
                        | (Mem.NumV nv1, Mem.NumV nv2) -> Mem.BoolV(nv1 = nv2)
                        | (Mem.BoolV b1, Mem.BoolV b2) -> Mem.BoolV(b1 = b2)
                        | (_, _) -> failwith (F.asprintf "Invalid equal-to: %a = %a" Ast.pp_e e1 Ast.pp_e e2)
                     end
    | And (e1, e2) -> begin
                        match ((interp_e e1 (env, mem)), (interp_e e2 (env, mem))) with
                        | (Mem.BoolV b1, Mem.BoolV b2) -> Mem.BoolV (b1 && b2)
                        | (_, _) -> failwith (Format.asprintf "Invalid logical-and: %a && %a" Ast.pp_e e1 Ast.pp_e e2)
                      end
    | Or (e1, e2) -> begin
                        match ((interp_e e1 (env,mem)), (interp_e e2 (env,mem))) with
                        | (Mem.BoolV b1, Mem.BoolV b2) -> Mem.BoolV (b1 || b2)
                        | (_, _) -> failwith (Format.asprintf "Invalid logival-or: %a || %a" Ast.pp_e e1 Ast.pp_e e2)
                     end
(* practice & homework *)
let rec interp_s (stmt : Ast.stmt) ((env, mem) : Env.t * Mem.t) : Env.t * Mem.t = 
   let  rec interp_rec stmt_list (env', mem') =
            match stmt_list with
            | st::stli -> interp_rec stli (interp_s st (env',mem'))
            | [] -> (env',mem')
   in
   match stmt with
   | IfStmt(e, true_s, false_s) -> begin
                                     match (interp_e e (env,mem)) with
                                     | Mem.BoolV true -> interp_rec true_s (env,mem)
                                     | Mem.BoolV false -> begin
                                                            match false_s with
                                                            | None -> (env, mem)
                                                            | Some false_s -> interp_rec false_s (env, mem)
                                                          end
                                     | _ -> failwith (F.asprintf "Not a boolean: %a" Ast.pp_e e)
                                   end
   | WhileStmt(e, s_list) -> begin
                                match (interp_e e (env,mem)) with
                                | Mem.BoolV true -> interp_s (WhileStmt (e, s_list)) (interp_rec s_list (env,mem))
                                | Mem.BoolV false -> (env,mem)
                                | _ -> failwith (F.asprintf "Not a boolean: %a" Ast.pp_e e)
                             end
   | VarDeclStmt x -> begin
                        match (Env.mem x env) with
                        | false -> ((Env.insert x (Env.new_address()) env), mem)
                        | _ -> failwith(F.asprintf "%s is already declared" x)
                      end
   |StoreStmt(e1,e2) -> begin
                          match ((interp_e e1 (env,mem)), (interp_e e2 (env,mem))) with
                          | (Mem.AddressV a, v) -> (env, (Mem.insert a v mem))
                          | (_,_) -> failwith(F.asprintf "Not a memory address : %a" Ast.pp_e e1)
                        end

(* practice & homework *)
let interp (p : Ast.program) : Env.t * Mem.t =
    let rec interp_rec p (env', mem') =
        match p with
        | st::stli -> interp_rec stli (interp_s st (env', mem'))
        | [] -> (env', mem')
    in
    match p with
    | Program s -> interp_rec s ([],[])