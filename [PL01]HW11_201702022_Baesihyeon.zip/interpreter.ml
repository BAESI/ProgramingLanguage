module F = Format

(* practice & homework *)
let rec interp_e (s : Store.t) (e : Ast.expr) : Store.value =
  match e with
  | Num i -> Store.NumV i
  | Add (e1,e2) -> begin
                    match ((interp_e s e1), (interp_e s e2)) with
                    | (Store.NumV nv1, Store.NumV nv2) -> Store.NumV(nv1 + nv2)
                    | (_,_) -> failwith (F.asprintf "Invalid addtion: %a + %a" Ast.pp_e e1 Ast.pp_e e2)
                   end
  | Sub (e1,e2) -> begin
                    match ((interp_e s e1), (interp_e s e2)) with
                    | (Store.NumV nv1, Store.NumV nv2) -> Store.NumV (nv1 - nv2)
                    | (_ , _) -> failwith (F.asprintf "Invalid subtraction: %a - %a" Ast.pp_e e1 Ast.pp_e e2)
                    end
  | Id x -> Store.find x s
  | LetIn (x,e1,e2) -> interp_e (Store.insert x (interp_e s e1) s) e2
  | App (e1,e2) -> begin
                    match (interp_e s e1) with
                    | Store.ClosureV (x, ex, t) -> interp_e (Store.insert x (interp_e s e2) t) ex
                    | _ -> failwith (F.asprintf "Not a function %a" Ast.pp_e e1)
                   end
  | Fun (x,e1) -> Store.ClosureV (x,e1,s)
  | Lt(e1, e2) -> begin
                   match (interp_e s e1, interp_e s e2) with
                   | NumV n1,NumV n2 -> if n1 < n2 then ClosureV("x",Fun("Y",(Id "x")),[])
                                               else ClosureV("x",Fun("y",(Id "y")),[])
                   | _,_ -> failwith (F.asprintf "Invalid less-than: %a < %a" Ast.pp_e e1 Ast.pp_e e2)
                  end

(* practice & homework *)
let interp (p : Ast.fvae) : Store.value = 
  match p with
      | Prog a -> interp_e [] a
  
  
  